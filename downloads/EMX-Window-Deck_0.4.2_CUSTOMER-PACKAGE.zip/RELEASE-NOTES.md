# EMX Window Deck v0.4.2

This customer-ready release completes the radial Windows quick-access launcher and incorporates the final real-PC, Fortnite, keyboard, mouse, Xbox-controller, and PlayStation-controller testing pass.

## Highlights

- Fast radial access to running and minimized windows, installed apps, games, files, folders, websites, favorites, and workspaces.
- Rebindable keyboard and controller show/hide shortcuts with duplicate-input protection.
- Controller-operated on-screen keyboard for app and Advanced View searches.
- Advanced View for comparing, filtering, and switching several open windows without accidental navigation or collapse.
- Native Windows volume, desktop-picture, and lock-screen-picture controls.
- Direct Fortnite shortcut with truthful Running or Closed status.
- Signed Stable auto-updates through the public EMX release feed.

## Reliability fixes

- Mouse-wheel navigation remains inside Advanced View, even when a duplicate native open signal arrives.
- Hovering previews never switches, minimizes, or closes EMX.
- Normal launches and update restarts open visibly; optional Windows autostart remains quiet in the background.
- Saved Windows shortcuts such as Task Manager `.lnk` files launch through Windows Shell correctly.
- Dedicated favorite and workspace hotkeys fire once per physical press.
- Modifier shortcuts no longer also trigger the focused EMX page's single-key actions.
- Controller summon chords open and close reliably without interfering with normal Fortnite controls.
- Navigation, labels, hints, dialogs, and the controller keyboard remain readable at supported window sizes.

## Privacy and game safety

EMX Window Deck is local-first and does not use accounts, telemetry, ads, game injection, memory editing, gameplay automation, or anti-cheat interaction. Fortnite Mode reads normal local process information only.

## Included customer package

The customer ZIP contains the Setup EXE, a `README-FIRST.txt`, and a short silent MP4 walkthrough. Stable in-app updater artifacts are cryptographically signed separately.
