EMX WINDOW DECK 0.4.2
=========================

Thank you for choosing EMX Window Deck.

INSTALL
-------
1. Double-click SETUP-EMX-WINDOW-DECK.exe.
2. Complete the Windows installer.
3. Open EMX Window Deck from the Desktop or Start menu.
4. Follow the short first-run tutorial.

If Microsoft Defender SmartScreen appears, confirm that the file is named
SETUP-EMX-WINDOW-DECK.exe and came from the official EMX release page, then
choose More info > Run anyway. Never install a copy from an unofficial source.

QUICK START
-----------
- Use your configured keyboard shortcut to show or hide the radial launcher.
- On controller, use your configured Options/Menu button combination.
- Rotate with the mouse wheel, arrow keys, D-pad, bumpers, or left stick.
- Press Enter or A/Cross to open the selected app or window.
- Press Y/Triangle in Advanced View to open the controller keyboard.
- Press B/Circle or the Back button to return to the previous EMX page.

WHAT IT CAN DO
--------------
- Launch installed apps, games, EMX tools, files, folders, and websites.
- Switch to normal or minimized open windows.
- Pin favorites and create multi-app workspaces.
- Control master volume and change desktop or lock-screen pictures.
- Use keyboard, mouse, Xbox-compatible controllers, and PlayStation controllers.

UPDATES
-------
Open Settings > About & Updates > Stable > Check now.
Signed stable updates can download and restart automatically.

PRIVACY AND SAFETY
------------------
EMX Window Deck is local-first. It has no account, ads, analytics, telemetry,
game injection, memory editing, gameplay automation, or anti-cheat interaction.
Fortnite Mode only checks normal local process information.

HELP
----
- Watch EMX-WINDOW-DECK-WALKTHROUGH.mp4 in this ZIP.
- The system-tray EMX icon can always reopen the app and Settings.
- If a shortcut conflicts with another program, rebind it in Settings.
- Advanced View is optional; the radial Open Apps ring is the fastest switcher.

Official releases:
https://github.com/tjcorp420/emx-window-deck-updates/releases

Copyright EMX Tweaks. All rights reserved.
