# Privacy Statement

Effective: July 17, 2026

EMX Window Deck is a local Windows utility. It does not require an account and does not include telemetry, analytics, advertising, browser tracking, or behavioral profiling.

## Local information used

The application reads the minimum normal desktop information needed to provide its features:

- Visible user-facing window titles, process identifiers, executable names/paths, state, and monitor placement
- Executable icons
- Whether configured companion processes, including Fortnite, are currently running
- Connected monitor geometry
- Controller connection/input state when controller support is enabled

This information remains on the PC. The application does not inject into processes, inspect private memory, read game state, or communicate with anti-cheat software.

## Stored information

Preferences, favorites, hidden applications, workspaces, and shortcuts are stored locally as validated JSON under `%APPDATA%\EMX Tweaks\EMX Window Deck`. Writes are atomic. A malformed settings file may be renamed as a local recovery backup.

Export occurs only when the user chooses a destination. Import is explicitly initiated by the user and is subject to schema, size, path, shortcut, and collection limits.

## Network access

Ordinary use produces no application network traffic. A signed release may contact its configured release endpoint only when the user selects Check for Updates or a future opt-in automatic update feature is enabled. Unsigned builds ship with updating disabled.

## Logs

Local diagnostic logs contain application state and errors. The application does not intentionally log window titles, full settings, tokens, or secret material. Logs are not uploaded automatically.

## Removal

Uninstall the application, then delete `%APPDATA%\EMX Tweaks\EMX Window Deck` to remove saved preferences and logs. Portable use does not create an account or cloud record.
