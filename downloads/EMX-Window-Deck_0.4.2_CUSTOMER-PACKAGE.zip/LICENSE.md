# Proprietary License

Copyright © 2026 EMX Tweaks. All rights reserved.

The source code, artwork, branding, binaries, installers, and documentation in this repository are proprietary material owned by EMX Tweaks unless a third-party component states otherwise in its own license.

No permission is granted to copy, modify, distribute, sublicense, sell, publish, reverse engineer, or create derivative works from this project without prior written authorization from EMX Tweaks. Installation and ordinary use of an authorized binary release are permitted for its intended purpose.

Third-party libraries remain subject to their respective licenses. “EMX,” “EMX Tweaks,” the EMX logo, and associated visual identity are not licensed for reuse.

THE SOFTWARE IS PROVIDED “AS IS,” WITHOUT WARRANTY OF ANY KIND, TO THE MAXIMUM EXTENT PERMITTED BY LAW.
